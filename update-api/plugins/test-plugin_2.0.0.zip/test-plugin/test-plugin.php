<?php
/*
Plugin Name: Test Plugin
Plugin URI: https://example.com/
Description: A simple plugin for testing purposes.
Version: 2.0.0
Author: Your Name
Author URI: https://example.com/
*/

// Plugin activation hook
function test_plugin_activate()
{
    // Do nothing
}
register_activation_hook(__FILE__, 'test_plugin_activate');

// Plugin deactivation hook
function test_plugin_deactivate()
{
    // Do nothing
}
register_deactivation_hook(__FILE__, 'test_plugin_deactivate');
