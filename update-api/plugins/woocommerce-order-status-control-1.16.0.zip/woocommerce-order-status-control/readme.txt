=== WooCommerce Order Status Control ===
Author: skyverge
Tags: woocommerce
Requires at least: 5.6
Tested up to: 6.2
Requires PHP: 7.4

Automatically change order status to complete for all orders or just virtual orders when payment is successful

See http://docs.woocommerce.com/document/woocommerce-order-status-control/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-order-status-control' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
